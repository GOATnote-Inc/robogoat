#!/bin/bash
set -e

cd /workspace
rm -rf robocache && mkdir robocache && cd robocache

# Extract package
tar -xzf ~/optimization_package.tar.gz

# Build
rm -rf build && mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release -DCMAKE_CUDA_ARCHITECTURES=90 -DROBOCACHE_BUNDLE_CUTLASS=ON
make -j$(nproc) benchmark_optimization 2>&1 | tail -20

# Run C++ benchmark
echo "=== C++ Benchmark ==="
./benchmark_optimization | tee ../cpp_results.txt

# Build Python extension
cd ..
export LD_LIBRARY_PATH=$(python3 -c "import torch, os; print(os.path.join(os.path.dirname(torch.__file__), 'lib'))"):$LD_LIBRARY_PATH

python3 << 'PYBUILD'
import os, sys, torch
from torch.utils.cpp_extension import load

cutlass_dir = os.path.join('build', '_deps', 'cutlass-src', 'include')
ext = load(
    name='robocache_cuda',
    sources=[
        'kernels/cutlass/trajectory_resample.cu',
        'kernels/cutlass/trajectory_resample_optimized.cu',
        'kernels/cutlass/trajectory_resample_torch.cu',
    ],
    extra_include_paths=['kernels/cutlass', cutlass_dir],
    extra_cuda_cflags=['-O3', '-use_fast_math', '--expt-relaxed-constexpr', '--expt-extended-lambda', '-DNDEBUG', '-std=c++17', '-gencode=arch=compute_90,code=sm_90'],
    verbose=False,
)
print("Extension built")
PYBUILD

# Run Python tests
echo "=== Python Tests ==="
python3 test_optimization.py | tee python_results.txt

# NCU profiling
echo "=== NCU Profiling ==="
ncu --metrics sm__throughput.avg.pct_of_peak_sustained_elapsed,dram__throughput.avg.pct_of_peak_sustained_elapsed,gpu__compute_memory_throughput.avg.pct_of_peak_sustained_elapsed \
    --target-processes all \
    ./build/benchmark_optimization 2>&1 | grep -A 5 "trajectory_resample" | tee ncu_results.txt

echo "=== Results Summary ==="
echo "C++ results: cpp_results.txt"
echo "Python results: python_results.txt"
echo "NCU results: ncu_results.txt"

