#!/bin/bash
# build_and_test_phase2.sh
# Automated build and test for Phase 2: Multimodal Sensor Fusion on H100

set -e  # Exit on error

echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║       RoboCache Phase 2: Build & Test on H100                       ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
echo ""

# ============================================================================
# Environment Validation
# ============================================================================

echo "──────────────────────────────────────────────────────────────────────"
echo "1. Validating Environment"
echo "──────────────────────────────────────────────────────────────────────"

# Check CUDA
if ! command -v nvcc &> /dev/null; then
    echo "❌ ERROR: nvcc not found. CUDA Toolkit required."
    exit 1
fi

CUDA_VERSION=$(nvcc --version | grep "release" | awk '{print $5}' | cut -d',' -f1)
echo "✓ CUDA version: $CUDA_VERSION"

if [[ ! "$CUDA_VERSION" =~ ^13\. ]]; then
    echo "⚠️  WARNING: CUDA 13.x recommended, found $CUDA_VERSION"
fi

# Check GPU
if ! command -v nvidia-smi &> /dev/null; then
    echo "❌ ERROR: nvidia-smi not found"
    exit 1
fi

GPU_NAME=$(nvidia-smi --query-gpu=name --format=csv,noheader | head -n1)
echo "✓ GPU: $GPU_NAME"

if [[ ! "$GPU_NAME" =~ "H100" ]]; then
    echo "⚠️  WARNING: H100 recommended, found $GPU_NAME"
fi

# Check CMake
if ! command -v cmake &> /dev/null; then
    echo "❌ ERROR: cmake not found"
    exit 1
fi

CMAKE_VERSION=$(cmake --version | head -n1 | awk '{print $3}')
echo "✓ CMake version: $CMAKE_VERSION"

# Check Python & PyTorch
if ! python3 -c "import torch" 2>/dev/null; then
    echo "❌ ERROR: PyTorch not found"
    exit 1
fi

TORCH_VERSION=$(python3 -c "import torch; print(torch.__version__)")
echo "✓ PyTorch version: $TORCH_VERSION"

TORCH_CUDA=$(python3 -c "import torch; print('Yes' if torch.cuda.is_available() else 'No')")
echo "✓ PyTorch CUDA available: $TORCH_CUDA"

if [[ "$TORCH_CUDA" != "Yes" ]]; then
    echo "❌ ERROR: PyTorch CUDA support required"
    exit 1
fi

echo ""

# ============================================================================
# Clean Build
# ============================================================================

echo "──────────────────────────────────────────────────────────────────────"
echo "2. Building RoboCache (Phase 1 + Phase 2)"
echo "──────────────────────────────────────────────────────────────────────"

# Clean previous build
rm -rf build
mkdir -p build
cd build

# Configure with H100 architecture
echo "Configuring CMake for H100 (sm_90)..."
cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CUDA_ARCHITECTURES=90 \
    -DBUILD_TORCH_EXTENSION=ON \
    -DROBOCACHE_BUNDLE_CUTLASS=ON

echo ""
echo "Building C++ benchmarks and PyTorch extension..."
make -j$(nproc) 2>&1 | tee build.log

if [ $? -ne 0 ]; then
    echo "❌ Build failed. Check build.log"
    exit 1
fi

echo "✓ Build succeeded"
echo ""

# ============================================================================
# Install Python Package
# ============================================================================

echo "──────────────────────────────────────────────────────────────────────"
echo "3. Installing Python Package"
echo "──────────────────────────────────────────────────────────────────────"

cd ..
pip install -e . --no-build-isolation 2>&1 | tee install.log

if [ $? -ne 0 ]; then
    echo "❌ Installation failed"
    exit 1
fi

echo "✓ Installation succeeded"
echo ""

# Verify Python import
python3 -c "import robocache_cuda; print('✓ robocache_cuda imported successfully')"

echo ""

# ============================================================================
# Test Phase 1: Trajectory Resampling
# ============================================================================

echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║  PHASE 1: Trajectory Resampling Tests                               ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
echo ""

echo "──────────────────────────────────────────────────────────────────────"
echo "4a. C++ Benchmark (Trajectory Resampling)"
echo "──────────────────────────────────────────────────────────────────────"

if [ -f build/benchmark_trajectory_resample ]; then
    ./build/benchmark_trajectory_resample
    echo ""
else
    echo "⚠️  benchmark_trajectory_resample not found"
fi

echo "──────────────────────────────────────────────────────────────────────"
echo "4b. Python Test (Trajectory Resampling)"
echo "──────────────────────────────────────────────────────────────────────"

python3 test_optimization.py

echo ""

# ============================================================================
# Test Phase 2: Multimodal Fusion
# ============================================================================

echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║  PHASE 2: Multimodal Fusion Tests                                   ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
echo ""

echo "──────────────────────────────────────────────────────────────────────"
echo "5a. C++ Benchmark (Multimodal Fusion)"
echo "──────────────────────────────────────────────────────────────────────"

if [ -f build/benchmark_multimodal_fusion ]; then
    ./build/benchmark_multimodal_fusion
    echo ""
else
    echo "⚠️  benchmark_multimodal_fusion not found"
fi

echo "──────────────────────────────────────────────────────────────────────"
echo "5b. Python Test (Multimodal Fusion)"
echo "──────────────────────────────────────────────────────────────────────"

python3 test_multimodal_fusion.py

echo ""

echo "──────────────────────────────────────────────────────────────────────"
echo "5c. Python Example (Multimodal Fusion)"
echo "──────────────────────────────────────────────────────────────────────"

python3 examples/multimodal_fusion_example.py

echo ""

# ============================================================================
# NCU Profiling (Optional - requires sudo)
# ============================================================================

echo "──────────────────────────────────────────────────────────────────────"
echo "6. NCU Profiling (Optional)"
echo "──────────────────────────────────────────────────────────────────────"

if command -v ncu &> /dev/null; then
    echo "NCU available. Profile with:"
    echo "  sudo ncu --set full ./build/benchmark_multimodal_fusion"
else
    echo "NCU not available. Skip profiling."
fi

echo ""

# ============================================================================
# Summary
# ============================================================================

echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║  ✅ PHASE 2 BUILD & TEST COMPLETE                                    ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
echo ""
echo "Summary:"
echo "  ✓ Environment validated"
echo "  ✓ RoboCache built successfully"
echo "  ✓ Phase 1 (Trajectory Resampling) tested"
echo "  ✓ Phase 2 (Multimodal Fusion) tested"
echo ""
echo "Next steps:"
echo "  • Review benchmark results above"
echo "  • Profile with NCU for detailed analysis"
echo "  • Integrate into your training pipeline"
echo ""
echo "Documentation:"
echo "  • Phase 1: README.md"
echo "  • Phase 2: docs/multimodal_fusion.md"
echo ""

