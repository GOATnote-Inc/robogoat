#!/bin/bash
# Run this on H100 after: brev shell awesome-gpu-name --dir /workspace
set -e
cd /workspace/robocache
export LD_LIBRARY_PATH=$(python3 -c "import torch, os; print(os.path.join(os.path.dirname(torch.__file__), 'lib'))"):$LD_LIBRARY_PATH

# Build optimization benchmark
cd build
make -j$(nproc) benchmark_optimization

# Run C++ benchmark
echo "=== C++ Benchmark ==="
./benchmark_optimization

# Build Python extension with optimized kernel
cd /workspace/robocache
python3 << 'PYBUILD'
import os, sys, torch
from torch.utils.cpp_extension import load

cutlass_dir = 'build/_deps/cutlass-src/include'
ext = load(
    name='robocache_cuda',
    sources=[
        'kernels/cutlass/trajectory_resample.cu',
        'kernels/cutlass/trajectory_resample_optimized.cu',
        'kernels/cutlass/trajectory_resample_torch.cu',
    ],
    extra_include_paths=['kernels/cutlass', cutlass_dir],
    extra_cuda_cflags=['-O3', '-use_fast_math', '--expt-relaxed-constexpr', '--expt-extended-lambda', '-std=c++17', '-gencode=arch=compute_90,code=sm_90'],
    verbose=False,
)
print(f"Built: {[f for f in dir(ext) if 'resample' in f]}")
PYBUILD

# Run Python tests
echo ""
echo "=== Python Tests ==="
python3 test_optimization.py

# NCU profiling
echo ""
echo "=== NCU Profiling ==="
ncu --metrics dram__throughput.avg.pct_of_peak_sustained_elapsed,sm__throughput.avg.pct_of_peak_sustained_elapsed \
    --target-processes all ./build/benchmark_optimization 2>&1 | grep -E "trajectory_resample|dram|sm__"

