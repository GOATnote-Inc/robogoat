#!/bin/bash
# Comprehensive validation of shared memory optimization
# Compares baseline vs optimized kernel with correctness and performance testing

set -e

echo "=============================================================================="
echo "  RoboCache Optimization Validation"
echo "=============================================================================="
echo ""

# Validation
cd build || { echo "Error: Run from robocache/ directory"; exit 1; }
export PATH=/usr/local/cuda/bin:$PATH

# Check GPU
GPU=$(nvidia-smi --query-gpu=name --format=csv,noheader | head -1)
echo "GPU: $GPU"

if [[ ! "$GPU" =~ "H100" ]]; then
    echo "WARNING: Optimizations tuned for H100, detected: $GPU"
fi

echo ""
echo "=== Building Validation Test ==="

# Build comprehensive validation
nvcc -O3 -arch=sm_90 -std=c++17 -use_fast_math \
  -I_deps/cutlass-src/include \
  -o validate_opt \
  - << 'EOFVALIDATE'
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <iostream>
#include <chrono>
#include <cmath>

// Baseline kernel
namespace baseline {
__global__ void trajectory_resample_kernel(
    const float* __restrict__ source_data, const float* __restrict__ source_times,
    const float* __restrict__ target_times, float* __restrict__ output_data,
    int batch_size, int source_length, int target_length, int action_dim
) {
    int batch_idx = blockIdx.x, target_idx = blockIdx.y, tid = threadIdx.x;
    if (batch_idx >= batch_size || target_idx >= target_length) return;
    __shared__ float s_target_time; __shared__ int s_left_idx, s_right_idx; __shared__ float s_weight;
    if (tid == 0) {
        s_target_time = target_times[batch_idx * target_length + target_idx];
        int low = 0, high = source_length - 1;
        while (low < high - 1) {
            int mid = (low + high) >> 1;
            if (source_times[batch_idx * source_length + mid] <= s_target_time) low = mid;
            else high = mid;
        }
        s_left_idx = low; s_right_idx = min(low + 1, source_length - 1);
        float t_left = source_times[batch_idx * source_length + s_left_idx];
        float t_right = source_times[batch_idx * source_length + s_right_idx];
        float delta = t_right - t_left;
        s_weight = (delta < 1e-6f) ? 0.0f : fminf(fmaxf((s_target_time - t_left) / delta, 0.0f), 1.0f);
    }
    __syncthreads();
    const float* batch_source = source_data + batch_idx * source_length * action_dim;
    float* batch_output = output_data + batch_idx * target_length * action_dim;
    for (int dim = tid; dim < action_dim; dim += 256) {
        float val_left = batch_source[s_left_idx * action_dim + dim];
        float val_right = batch_source[s_right_idx * action_dim + dim];
        batch_output[target_idx * action_dim + dim] = fmaf(s_weight, val_right - val_left, val_left);
    }
}
}

// Optimized kernel
#include "../kernels/cutlass/trajectory_resample_optimized.cu"
using namespace robocache::kernels::optimized;

void run_validation(int batch, int src, int tgt, int dim) {
    size_t src_data_size = batch * src * dim * sizeof(float);
    size_t src_times_size = batch * src * sizeof(float);
    size_t tgt_times_size = batch * tgt * sizeof(float);
    size_t out_data_size = batch * tgt * dim * sizeof(float);
    
    float *d_src, *d_st, *d_tt, *d_out_base, *d_out_opt;
    float *h_src = new float[batch * src * dim];
    float *h_st = new float[batch * src];
    float *h_tt = new float[batch * tgt];
    float *h_out_base = new float[batch * tgt * dim];
    float *h_out_opt = new float[batch * tgt * dim];
    
    for (int b = 0; b < batch; b++) {
        for (int s = 0; s < src; s++) {
            h_st[b * src + s] = float(s) / src;
            for (int d = 0; d < dim; d++) {
                h_src[b * src * dim + s * dim + d] = sinf(s * 0.1f + d * 0.01f);
            }
        }
        for (int t = 0; t < tgt; t++) h_tt[b * tgt + t] = float(t) / tgt;
    }
    
    cudaMalloc(&d_src, src_data_size); cudaMalloc(&d_st, src_times_size);
    cudaMalloc(&d_tt, tgt_times_size); cudaMalloc(&d_out_base, out_data_size);
    cudaMalloc(&d_out_opt, out_data_size);
    
    cudaMemcpy(d_src, h_src, src_data_size, cudaMemcpyHostToDevice);
    cudaMemcpy(d_st, h_st, src_times_size, cudaMemcpyHostToDevice);
    cudaMemcpy(d_tt, h_tt, tgt_times_size, cudaMemcpyHostToDevice);
    
    printf("=== Config: batch=%d src=%d tgt=%d dim=%d ===\n", batch, src, tgt, dim);
    
    dim3 grid_base(batch, tgt); dim3 block_base(256);
    for (int i = 0; i < 20; i++) 
        baseline::trajectory_resample_kernel<<<grid_base, block_base>>>(d_src, d_st, d_tt, d_out_base, batch, src, tgt, dim);
    cudaDeviceSynchronize();
    
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < 100; i++)
        baseline::trajectory_resample_kernel<<<grid_base, block_base>>>(d_src, d_st, d_tt, d_out_base, batch, src, tgt, dim);
    cudaDeviceSynchronize();
    double ms_base = std::chrono::duration<double, std::milli>(std::chrono::high_resolution_clock::now() - start).count() / 100.0;
    
    for (int i = 0; i < 20; i++)
        resample_trajectories_optimized(d_src, d_st, d_tt, d_out_opt, batch, src, tgt, dim, 0);
    cudaDeviceSynchronize();
    
    start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < 100; i++)
        resample_trajectories_optimized(d_src, d_st, d_tt, d_out_opt, batch, src, tgt, dim, 0);
    cudaDeviceSynchronize();
    double ms_opt = std::chrono::duration<double, std::milli>(std::chrono::high_resolution_clock::now() - start).count() / 100.0;
    
    cudaMemcpy(h_out_base, d_out_base, out_data_size, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_out_opt, d_out_opt, out_data_size, cudaMemcpyDeviceToHost);
    
    double max_diff = 0.0, sum_diff = 0.0;
    int total = batch * tgt * dim;
    for (int i = 0; i < total; i++) {
        double diff = fabs(h_out_base[i] - h_out_opt[i]);
        max_diff = fmax(max_diff, diff);
        sum_diff += diff;
    }
    
    double bytes = src_data_size + src_times_size + tgt_times_size + out_data_size;
    double bw_base = (bytes / 1e9) / (ms_base / 1000.0);
    double bw_opt = (bytes / 1e9) / (ms_opt / 1000.0);
    
    printf("Correctness: max_diff=%.6e, avg_diff=%.6e, %s\n", max_diff, sum_diff/total, (max_diff < 1e-4) ? "✓ PASS" : "✗ FAIL");
    printf("Baseline:  %.3f ms, %.1f GB/s, %.2f%% eff\n", ms_base, bw_base, bw_base/3000*100);
    printf("Optimized: %.3f ms, %.1f GB/s, %.2f%% eff\n", ms_opt, bw_opt, bw_opt/3000*100);
    printf("Speedup:   %.2fx\n\n", ms_base / ms_opt);
    
    delete[] h_src; delete[] h_st; delete[] h_tt; delete[] h_out_base; delete[] h_out_opt;
    cudaFree(d_src); cudaFree(d_st); cudaFree(d_tt); cudaFree(d_out_base); cudaFree(d_out_opt);
}

int main() {
    cudaDeviceProp prop;
    cudaGetDeviceProperties(&prop, 0);
    printf("GPU: %s (sm_%d%d)\n", prop.name, prop.major, prop.minor);
    printf("HBM Peak: 3000 GB/s (H100 PCIe)\n\n");
    
    run_validation(256, 100, 50, 32);
    run_validation(32, 100, 50, 32);
    run_validation(1024, 100, 50, 32);
    run_validation(256, 500, 250, 32);
    
    return 0;
}
EOFVALIDATE

echo ""
echo "=== Running Validation ==="
./validate_opt

echo ""
echo "=============================================================================="
echo "  Validation Complete"
echo "=============================================================================="
echo ""
echo "Results documented in: VALIDATION_REPORT.md"
echo ""
echo "To reproduce:"
echo "  cd robocache && ./validate_optimization.sh"
echo ""

