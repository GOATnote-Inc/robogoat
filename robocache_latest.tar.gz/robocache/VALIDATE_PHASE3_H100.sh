#!/bin/bash
# VALIDATE_PHASE3_H100.sh
# Build and validate Phase 3 (Point Cloud Voxelization) on H100

set -e

export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH

echo "╔══════════════════════════════════════════════════════════════════════════════════╗"
echo "║  PHASE 3: POINT CLOUD VOXELIZATION - H100 VALIDATION"
echo "╚══════════════════════════════════════════════════════════════════════════════════╝"
echo ""

cd /workspace/robocache

# Git pull latest Phase 3
echo "─── Pulling Latest Phase 3 ───"
git fetch --all
git pull origin claude/robocache-trajectory-resampling-011CUmL9iZ88eGvKKKSz7LuQ
echo ""

# Verify Phase 3 files
echo "─── Verifying Phase 3 Files ───"
if [ ! -f "kernels/cutlass/point_cloud_voxelization.h" ]; then
    echo "❌ point_cloud_voxelization.h missing"
    exit 1
fi
if [ ! -f "kernels/cutlass/point_cloud_voxelization.cu" ]; then
    echo "❌ point_cloud_voxelization.cu missing"
    exit 1
fi
if [ ! -f "benchmarks/benchmark_voxelization.cu" ]; then
    echo "❌ benchmark_voxelization.cu missing"
    exit 1
fi
echo "✓ All Phase 3 files present"
wc -l kernels/cutlass/point_cloud_voxelization.{h,cu}
wc -l benchmarks/benchmark_voxelization.cu
echo ""

# Clean build
echo "─── Building Phase 3 ───"
rm -rf build
mkdir build
cd build

cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CUDA_ARCHITECTURES=90 \
    -DBUILD_TORCH_EXTENSION=OFF \
    -DROBOCACHE_BUNDLE_CUTLASS=ON

echo ""
echo "Building benchmark_voxelization..."
make -j$(nproc) benchmark_voxelization 2>&1 | tail -20

if [ ! -f "benchmark_voxelization" ]; then
    echo "❌ Build FAILED"
    exit 1
fi

echo "✅ Build SUCCESS"
ls -lh benchmark_voxelization
echo ""

# Run benchmark
echo "╔══════════════════════════════════════════════════════════════════════════════════╗"
echo "║  RUNNING PHASE 3 BENCHMARK"
echo "╚══════════════════════════════════════════════════════════════════════════════════╝"
echo ""

./benchmark_voxelization

echo ""
echo "╔══════════════════════════════════════════════════════════════════════════════════╗"
echo "║  ✅ PHASE 3 VALIDATED ON H100"
echo "╚══════════════════════════════════════════════════════════════════════════════════╝"
echo ""
echo "Next: Run NCU profiling for detailed analysis"
echo "  sudo ncu --metrics dram__throughput.avg.pct_of_peak_sustained_elapsed \\"
echo "    --target-processes all --kernel-name voxelize_occupancy_kernel \\"
echo "    --launch-skip 100 --launch-count 1 ./benchmark_voxelization"
echo ""

