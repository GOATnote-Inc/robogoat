#!/bin/bash
# DEPLOY_AND_VALIDATE_H100.sh
# Deploy Phase 2 to H100 and run critical validation
# Expert review mode

set -e

REPO_ROOT="/Users/kiteboard/robogoat/robocache"
H100_HOST="awesome-gpu-name"

echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║  DEPLOY & VALIDATE: Phase 2 on H100                                 ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
echo ""

# ============================================================================
# Step 1: Package Phase 2 files
# ============================================================================

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "1. Packaging Phase 2 Files"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

cd "$REPO_ROOT/.."

tar czf robocache_phase2_deploy.tar.gz \
    robocache/kernels/cutlass/multimodal_fusion.h \
    robocache/kernels/cutlass/multimodal_fusion.cu \
    robocache/kernels/cutlass/multimodal_fusion_torch.cu \
    robocache/kernels/cutlass/trajectory_resample.h \
    robocache/kernels/cutlass/trajectory_resample.cu \
    robocache/kernels/cutlass/trajectory_resample_optimized.cu \
    robocache/kernels/cutlass/trajectory_resample_production.cu \
    robocache/benchmarks/benchmark_multimodal_fusion.cu \
    robocache/CMakeLists.txt \
    robocache/cmake/ThirdPartyCUTLASS.cmake

echo "✓ Created robocache_phase2_deploy.tar.gz"
ls -lh robocache_phase2_deploy.tar.gz
echo ""

# ============================================================================
# Step 2: Deploy to H100
# ============================================================================

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "2. Deploying to H100"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

cat << 'REMOTE_SCRIPT' | brev shell $H100_HOST --dir /workspace 2>&1
set -e
export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH

echo "Preparing workspace..."
mkdir -p /workspace/uploads
echo "✓ Ready to receive tarball"
REMOTE_SCRIPT

# Copy tarball
echo "Copying tarball to H100..."
brev scp robocache_phase2_deploy.tar.gz $H100_HOST:/workspace/uploads/

echo "✓ Files copied to H100"
echo ""

# ============================================================================
# Step 3: Extract and build on H100
# ============================================================================

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "3. Building Phase 2 on H100"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

cat << 'BUILD_SCRIPT' | brev shell $H100_HOST --dir /workspace 2>&1
set -e
export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH

cd /workspace

echo "─── Extracting Phase 2 files ───"
tar xzf uploads/robocache_phase2_deploy.tar.gz
echo "✓ Files extracted"
echo ""

cd robocache

echo "─── Building ───"
rm -rf build
mkdir build
cd build

cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CUDA_ARCHITECTURES=90 \
    -DBUILD_TORCH_EXTENSION=OFF \
    -DROBOCACHE_BUNDLE_CUTLASS=ON \
    2>&1 | tee cmake.log

echo ""
echo "CMake configuration complete. Building..."

make -j$(nproc) benchmark_multimodal_fusion 2>&1 | tee build.log

if [ -f benchmark_multimodal_fusion ]; then
    echo "✓ Build SUCCESS"
    ls -lh benchmark_multimodal_fusion
else
    echo "❌ Build FAILED - benchmark binary not found"
    tail -50 build.log
    exit 1
fi
BUILD_SCRIPT

echo ""

# ============================================================================
# Step 4: Run benchmark
# ============================================================================

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "4. Running Benchmark"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

cat << 'BENCH_SCRIPT' | brev shell $H100_HOST --dir /workspace 2>&1 | tee benchmark_output.txt
set -e
export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH

cd /workspace/robocache/build

echo "Running multimodal fusion benchmark..."
./benchmark_multimodal_fusion

echo ""
echo "✓ Benchmark complete"
BENCH_SCRIPT

echo ""
echo "✓ Benchmark output saved to: benchmark_output.txt"
echo ""

# ============================================================================
# Step 5: Analyze results
# ============================================================================

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "5. CRITICAL ANALYSIS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

python3 << 'PYEOF'
import re

with open('benchmark_output.txt', 'r') as f:
    output = f.read()

print("\nExtracting performance metrics...")
print("="*80)

# Find all latency/bandwidth/efficiency measurements
configs = []
latencies = []
bandwidths = []
efficiencies = []

for line in output.split('\n'):
    if 'Configuration:' in line and '(' in line:
        configs.append(line.split('Configuration:')[1].strip())
    elif 'Average latency:' in line:
        match = re.search(r'([\d.]+)\s*ms', line)
        if match:
            latencies.append(float(match.group(1)))
    elif 'Bandwidth:' in line and 'GB/s' in line:
        match = re.search(r'([\d.]+)\s*GB/s', line)
        if match:
            bandwidths.append(float(match.group(1)))
    elif 'HBM3 efficiency:' in line:
        match = re.search(r'([\d.]+)%', line)
        if match:
            efficiencies.append(float(match.group(1)))

if not configs:
    print("❌ Could not parse benchmark output")
    exit(1)

print("\nPERFORMANCE SUMMARY:")
print("="*80)

for i, config in enumerate(configs):
    if i < len(latencies):
        print(f"\n{config}")
        print(f"  Latency:     {latencies[i]:.3f} ms")
        print(f"  Bandwidth:   {bandwidths[i]:.1f} GB/s")
        print(f"  Efficiency:  {efficiencies[i]:.2f}%")

print("\n" + "="*80)
print("✅ Phase 2 multimodal fusion validated on H100")
print("="*80)
PYEOF

echo ""
echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║  ✅ PHASE 2 VALIDATION COMPLETE                                      ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
echo ""
echo "Results saved to: benchmark_output.txt"
echo ""
echo "Next steps:"
echo "  • Review performance metrics above"
echo "  • Run NCU profiling: brev shell $H100_HOST"
echo "  • sudo ncu --set full ./build/benchmark_multimodal_fusion"
echo ""

