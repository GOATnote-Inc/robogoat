#!/usr/bin/env bash
# Run this script ON the GPU instance
set -euo pipefail

cd /workspace
rm -rf robocache
tar xzf robocache_v2.tar.gz 2>/dev/null || tar xzf robocache_fixed.tar.gz 2>/dev/null || echo "Using existing robocache dir"
cd robocache

chmod +x gpu_build_and_test.sh
./gpu_build_and_test.sh 2>&1 | tee /workspace/build_results.log

echo ""
echo "========================================"
echo "Build complete! Results saved to:"
echo "/workspace/build_results.log"
echo "========================================"

