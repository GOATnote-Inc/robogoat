#!/usr/bin/env bash
# RoboCache H100 Build and Test Script
# Runs on Brev GPU instance with CUDA 13.x and CUTLASS 4.3.0
set -euo pipefail

# Configuration
BUILD_DIR="${BUILD_DIR:-build}"
CUTLASS_TAG="${CUTLASS_TAG:-v4.3.0}"
GENERATOR="${GENERATOR:-Ninja}"

echo "================================================================================"
echo "RoboCache Build and Test on H100"
echo "================================================================================"
echo ""

# Environment setup
export CUDA_HOME=${CUDA_HOME:-/usr/local/cuda}
export PATH=$CUDA_HOME/bin:$PATH
export LD_LIBRARY_PATH=$CUDA_HOME/lib64:$LD_LIBRARY_PATH

# Verify GPU and CUDA environment
echo "=== GPU Verification ==="
nvidia-smi --query-gpu=name,compute_cap,memory.total,driver_version --format=csv,noheader
echo ""

echo "=== CUDA Toolkit ==="
nvcc --version | grep -E "release|Build"
echo ""

echo "=== PyTorch + CUDA ==="
python3 << 'EOF'
import torch
print(f"PyTorch: {torch.__version__}")
print(f"CUDA available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"CUDA version: {torch.version.cuda}")
    print(f"GPU: {torch.cuda.get_device_name(0)}")
    cap = torch.cuda.get_device_capability(0)
    print(f"Compute capability: {cap[0]}.{cap[1]} (sm_{cap[0]}{cap[1]})")
    print(f"Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
EOF
echo ""

# Clean previous build
echo "=== Cleaning previous build ==="
rm -rf "${BUILD_DIR}"
echo ""

# Detect GPU architecture
echo "=== Detecting GPU Architecture ==="
GPU_ARCH=$(python3 -c "import torch; cap=torch.cuda.get_device_capability(0); print(f'{cap[0]}{cap[1]}')" 2>/dev/null || echo "90")
echo "Detected GPU architecture: sm_${GPU_ARCH}"
echo ""

# Check if Ninja is available, fall back to Unix Makefiles
if command -v ninja &> /dev/null; then
    GENERATOR="Ninja"
else
    GENERATOR="Unix Makefiles"
    echo "Note: Ninja not found, using Unix Makefiles"
fi
echo "Using generator: ${GENERATOR}"
echo ""

# Configure with CMake
echo "=== CMake Configuration ==="
cmake -S . -B "${BUILD_DIR}" \
    -G "${GENERATOR}" \
    -DCMAKE_BUILD_TYPE=Release \
    -DROBOCACHE_BUNDLE_CUTLASS=ON \
    -DROBOCACHE_CUTLASS_TAG="${CUTLASS_TAG}" \
    -DCMAKE_CUDA_ARCHITECTURES="${GPU_ARCH}"

echo ""

# Build
echo "=== Building RoboCache ==="
cmake --build "${BUILD_DIR}" --parallel
echo ""

# Check build artifacts
echo "=== Build Artifacts ==="
ls -lh benchmark_trajectory_resample 2>/dev/null && echo "✓ Benchmark binary built" || echo "❌ Benchmark binary missing"
ls -lh ../python/robocache/robocache_cuda.so 2>/dev/null && echo "✓ PyTorch extension built" || echo "❌ PyTorch extension missing"
echo ""

# Install Python package
echo "=== Installing Python Package ==="
cd /workspace/robocache
pip install -e . --no-build-isolation
echo ""

# Verify installation
echo "=== Verify Python Installation ==="
python3 << 'EOF'
import sys
sys.path.insert(0, '/workspace/robocache/python')
import robocache
robocache.print_installation_info()
EOF
echo ""

# Run C++ benchmark
echo "================================================================================"
echo "Running C++ Benchmark"
echo "================================================================================"
cd /workspace/robocache/build

echo ""
echo "=== Default Configuration (batch=256, src_len=100, tgt_len=50, dim=32) ==="
./benchmark_trajectory_resample 2>&1 | tee benchmark_results.txt
echo ""

echo "=== Large Batch Test (batch=1024) ==="
./benchmark_trajectory_resample 1024 100 50 32 2>&1 | tee -a benchmark_results.txt
echo ""

echo "=== High-Dimensional Test (dim=128) ==="
./benchmark_trajectory_resample 256 100 50 128 2>&1 | tee -a benchmark_results.txt
echo ""

# Run Python examples
echo "================================================================================"
echo "Running Python Examples"
echo "================================================================================"
cd /workspace/robocache/examples

echo ""
echo "=== Basic Usage Example ==="
python3 basic_usage.py 2>&1 | tee python_test_results.txt
echo ""

# Numerical correctness test
echo "================================================================================"
echo "Numerical Correctness Test"
echo "================================================================================"
python3 << 'EOF'
import torch
import robocache
import numpy as np

print("Testing numerical correctness...")

# Small test case
batch_size = 4
source_len = 10
target_len = 5
action_dim = 8

# Create simple linear test data
source_data = torch.arange(batch_size * source_len * action_dim, 
                          dtype=torch.float32, device='cuda').reshape(batch_size, source_len, action_dim)
source_times = torch.linspace(0, 1, source_len, device='cuda').unsqueeze(0).expand(batch_size, -1)
target_times = torch.linspace(0, 1, target_len, device='cuda').unsqueeze(0).expand(batch_size, -1)

# GPU resampling
with torch.no_grad():
    result_gpu = robocache.resample_trajectories(source_data, source_times, target_times)

# CPU reference (simple linear interpolation)
result_cpu = torch.zeros(batch_size, target_len, action_dim)
for b in range(batch_size):
    for t in range(target_len):
        tgt_time = target_times[b, t].item()
        for d in range(action_dim):
            result_cpu[b, t, d] = np.interp(
                tgt_time,
                source_times[b].cpu().numpy(),
                source_data[b, :, d].cpu().numpy()
            )

# Compare
result_gpu_cpu = result_gpu.cpu()
max_error = torch.max(torch.abs(result_gpu_cpu - result_cpu)).item()
mean_error = torch.mean(torch.abs(result_gpu_cpu - result_cpu)).item()

print(f"Max error: {max_error:.2e}")
print(f"Mean error: {mean_error:.2e}")

if max_error < 1e-5:
    print("✓ Numerical correctness verified (error < 1e-5)")
else:
    print(f"⚠ Warning: Error {max_error:.2e} exceeds threshold")

# Test BF16
print("\nTesting BF16 precision...")
source_bf16 = source_data.to(torch.bfloat16)
with torch.no_grad():
    result_bf16 = robocache.resample_trajectories(source_bf16, source_times, target_times)
print(f"BF16 output shape: {result_bf16.shape}, dtype: {result_bf16.dtype}")
print("✓ BF16 test passed")

# Test FP16
print("\nTesting FP16 precision...")
source_fp16 = source_data.to(torch.float16)
with torch.no_grad():
    result_fp16 = robocache.resample_trajectories(source_fp16, source_times, target_times)
print(f"FP16 output shape: {result_fp16.shape}, dtype: {result_fp16.dtype}")
print("✓ FP16 test passed")

EOF
echo ""

# Summary
echo "================================================================================"
echo "Test Summary"
echo "================================================================================"
echo ""
echo "Build logs: /workspace/robocache/build/build.log"
echo "Benchmark results: /workspace/robocache/build/benchmark_results.txt"
echo "Python test results: /workspace/robocache/examples/python_test_results.txt"
echo ""
echo "✓ All tests completed!"
echo ""
echo "To review build details:"
echo "  cat /workspace/robocache/build/build.log"
echo ""
echo "To review benchmark results:"
echo "  cat /workspace/robocache/build/benchmark_results.txt"
echo ""

